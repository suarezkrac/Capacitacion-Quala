//
//  ViewController.m
//  MapKit
//
//  Created by Estudiante on 16/09/13.
//  Copyright (c) 2013 QUALA. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize worldView, locationTitleField;


- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    if (self)
    {
        locationManager = [[CLLocationManager alloc] init];
        [locationManager setDelegate:self];
        [locationManager setDesiredAccuracy:kCLLocationAccuracyBest];
        [locationManager startUpdatingLocation];
    }
  //  [worldView setShowsUserLocation:YES];
  //  [worldView setRegion:region animated:YES];
    [self foundLocation:[[CLLocation alloc] initWithLatitude:region.center.latitude longitude:region.center.longitude]];
}


- (void) mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    NSLog(@"ENTRO");
    CLLocationCoordinate2D loc = [userLocation coordinate];
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(loc, 250, 250);
    [worldView setRegion:region animated:YES];
}
 

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)changeMapType:(id)sender
{
    int typeIndex = [sender selectedSegmentIndex];
    if (typeIndex == 0)
    {
        [worldView setMapType:MKMapTypeStandard];
    }
    else if (typeIndex == 1)
    {
        [worldView setMapType:MKMapTypeSatellite];
    }
    else if (typeIndex == 2)
    {
        [worldView setMapType:MKMapTypeHybrid];
    }
}

- (void) findLocation
{
    
}

- (void) setRegion1:(CLLocation *)loc
{
    CLLocationCoordinate2D coord = [loc coordinate];
    region = MKCoordinateRegionMakeWithDistance(coord, 250, 250);
}

- (void) foundLocation:(CLLocation *) loc
{
    NSLog(@"locación: %f , %f", loc.coordinate.latitude, loc.coordinate.longitude);
    CLLocationCoordinate2D coord = [loc coordinate];
    mapPoint * mp = [[mapPoint alloc] initWithCoordinate:coord title:[locationTitleField text]];
    [worldView addAnnotation:mp];
    region = MKCoordinateRegionMakeWithDistance(coord, 250, 250);
    [worldView setRegion:region animated:YES]; 
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }
    NSString * identifier = @"mapPoint";
    MKAnnotationView * annotationView = [self.worldView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annotationView)
    {
        annotationView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        // si la imagen es muy grande, se debe asignar el tamaño primero
        annotationView.image = [UIImage imageNamed:@"casa.png"];
    }
    else
    {
        annotationView.annotation = annotation;
    }
    return annotationView;
}



/*
- (void) locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
    NSLog(@"anterior locacion: %f , %f", oldLocation.coordinate.latitude, oldLocation.coordinate.longitude);
    NSLog(@"nueva locacion: %f , %f",  newLocation.coordinate.latitude, newLocation.coordinate.longitude);
    [self foundLocation:newLocation];
    [locationManager stopUpdatingLocation];
}
 */


 

@end
